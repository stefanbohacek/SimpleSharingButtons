Licence

The Simple Icons set and associated files are distributed by Dan Leech under the Free Art Licence. Company logos and icons may be subject to trademark and copyright conditions. Always check before deploying other companies� branding on your own website.

http://simpleicons.org/