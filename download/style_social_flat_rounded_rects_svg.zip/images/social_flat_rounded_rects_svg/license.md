# Social Flat Rounded Rects
## by [Aha-Soft Team](http://www.aha-soft.com/free-icons/) 
**License:**  Creative Commons (Attribution 3.0 Unported)

*Dec 26th, 2014*
